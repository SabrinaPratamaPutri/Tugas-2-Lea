<?php
session_start();

if(!isset($_SESSION["login"])) 
{
  header("location:index.php");
  exit;
    
 }
require 'function.php';


if( isset($_POST["submit"])) {



if( tambah ($_POST) > 0 ) {
  echo "
      <script>
        alert('data berhasil ditambah!')
        document.location.href = 'transaksi.php';
      </script>

  "; 

}else {
  echo "
    <script>
        alert('data gagal ditambah!');
        document.location.href = 'transaksi.php';
      </script>    

  ";

}
}
?>
    
 <!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Aneka CarWash</title>
     <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
     <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
   <link rel="stylesheet" type="text/css" href="style.css">

    <style>
input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

div {
  border-radius: 5px;
  padding: 0px;
}
</style>
 
 
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">Aneka CarWash</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;">  &nbsp; <a href="logout.php" class="btn btn-danger square-btn-adjust">Logout</a> </div>
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
        <li class="text-center">
                    <img src="assets/img/mobill.jpg" class="user-image img-responsive"/>
          </li>
        
          
                     <li>
                        <a  href="kend.php" ><i class="fa fa-car fa-3x"></i>Jenis Kendaraan</a>
                    </li>
                      <li>
                        <a  href="transaksi.php"><i class="fa fa-money fa-3x"></i>Transaksi</a>
                    </li>
                    <li>
                        <a  href="lapr.php"><i class="fa fa-table fa-3x"></i> Rekap Data</a>
                    </li>
              
                  
                </ul>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">


  <legend>Tambah Data Transaksi</legend>

<div>
  <form action="" method="post">
    <label>No. Nota</label>
    <input type="text" name="no_nota" placeholder="ex: 201">

    <label>Nama Pelanggan</label>
    <input type="text" name="nama_pelanggan" placeholder="ex: ani">

     <label>Jenis Kendaraan</label>
    <input type="text" name="jenis_kendaraan" placeholder="ex: mobil">

    <label>Biaya</label>
    <input type="text" name="biaya_jasa" placeholder="ex: 400.000">

     <label>Jumlah Kendaraan</label>
    <input type="text" name="jumlah_kendaraan" placeholder="ex: 3">
  
    <input type="submit" name="submit" value="Submit">
  </form>
</div>


                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
</body>
</html>



 