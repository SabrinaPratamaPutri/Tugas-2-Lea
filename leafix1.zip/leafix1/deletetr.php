<?php 

session_start();

if(!isset($_SESSION["login"])) 
{
	header("location:index.php");
	exit;
 	  
 }

require 'function.php';

$no_nota = $_GET["no_nota"];

	if(delete($no_nota) > 0)
	{
		echo 
		"
			<script> alert ('Data Berhasil Dihapus');
			document.location.href = 'transaksi.php'
			</script>
		";
	}
	else
	{
		echo 
		"
			<script> alert ('Data Tidak Berhasil Dihapus');
			</script>
		";
	}


 ?>