<?php 

//koneksi ke database
 $db = mysqli_connect("localhost","root","","lea");

 //fungsi query
function query($query)
{
	global $db;
	$result = mysqli_query ($db , $query);
	$rows = [];
	while ($row = mysqli_fetch_assoc($result)) 
	{
		$rows[] = $row;
	}

	return $rows;
}

function biaya($data)
{
	global $db;
	$id_jenis = $data["id_jenis"];
	$jenis_kendaraan = $data["jenis_kendaraan"];
	$biaya_jasa = $data["biaya_jasa"];

	mysqli_query($db, "INSERT INTO biaya VALUES ('','$id_jenis','$jenis_kendaraan','$biaya_jasa')");

	return mysqli_affected_rows($db);

}

function transaksi($data)
{
	global $db;
 	$no_nota = $data["no_nota"];  ; 
	$nama_pelanggan	= $data["nama_pelanggan"];  
 	$jenis_kendaraan = $data["jenis_kendaraan"]; 
 	$biaya_jasa = $data["biaya_jasa"]; 
 	$jumlah_kendaraan = $data["jumlah_kendaraan"];  
 	$total_bayar = $biaya_jasa*$jumlah_kendaraan; 
 	$tanggal = date('Y-m-d');

	mysqli_query($db, "INSERT INTO transaksi VALUES ('','$no_nota','$nama_pelanggan','$jenis_kendaraan','$biaya_jasa','$jumlah_kendaraan','$total_bayar','$tanggal')");

	return mysqli_affected_rows($db);

}

function tambah($data)
{
	global $db;
 	$no_nota = $data["no_nota"];  
	$nama_pelanggan	= $data["nama_pelanggan"];  
 	$jenis_kendaraan = $data["jenis_kendaraan"]; 
 	$biaya_jasa = $data["biaya_jasa"]; 
 	$jumlah_kendaraan = $data["jumlah_kendaraan"];  
 	$total_harga = $data["total_harga"]; 
 	$total_harga = ($biaya_jasa*$jumlah_kendaraan); 
 	$tanggal = date('Y-m-d');

	mysqli_query($db, "INSERT INTO transaksi VALUES ('$no_nota','$nama_pelanggan','$jenis_kendaraan','$biaya_jasa','$jumlah_kendaraan','$total_harga','$tanggal')");

	return mysqli_affected_rows($db);

}

function tambah2($data)
{
	global $db;
	$id_jenis = $data["id_jenis"];  
 	$jenis_kendaraan = $data["jenis_kendaraan"];  
	$biaya_jasa	= $data["biaya_jasa"];  

	mysqli_query($db, "INSERT INTO biaya VALUES ('$id_jenis','$jenis_kendaraan','$biaya_jasa')");

	return mysqli_affected_rows($db);

}

function delete($no_nota)
{
	global $db;
	mysqli_query($db, "DELETE FROM transaksi WHERE no_nota = '$no_nota'");

	return mysqli_affected_rows($db);
}

function delete2($id_jenis)
{
	global $db;
	mysqli_query($db, "DELETE FROM biaya WHERE id_jenis = '$id_jenis'");

	return mysqli_affected_rows($db);
}

function edit($data)
{
	global $db; 
 	$no_nota = $data["no_nota"];  
	$nama_pelanggan	= $data["nama_pelanggan"];  
 	$jenis_kendaraan = $data["jenis_kendaraan"]; 
 	$biaya_jasa = $data["biaya_jasa"]; 
 	$jumlah_kendaraan = $data["jumlah_kendaraan"];   
 	$total_harga = $biaya_jasa*$jumlah_kendaraan; 
 	$tanggal = date('Y-m-d');

	mysqli_query($db, "UPDATE transaksi SET
					nama_pelanggan = '$nama_pelanggan',
					jenis_kendaraan = '$jenis_kendaraan',
					biaya_jasa = '$biaya_jasa',
					jumlah_kendaraan = '$jumlah_kendaraan',
					total_harga = '$total_harga', 
					tanggal = '$tanggal'
					WHERE no_nota = '$no_nota'");
	

	return mysqli_affected_rows($db);
}

function edit2($data)
{

 	global $db;
	$id_jenis = $data["id_jenis"];  
 	$jenis_kendaraan = $data["jenis_kendaraan"];  
	$biaya_jasa	= $data["biaya_jasa"]; 

	mysqli_query($db, "UPDATE biaya SET
					jenis_kendaraan = '$jenis_kendaraan',
					biaya_jasa = '$biaya_jasa'
					WHERE id_jenis = '$id_jenis'");
	
	return mysqli_affected_rows($db);
}






 ?>