<?php 

require 'function.php';



if(isset($_POST["login"])) 
{
	$username = $_POST["username"];
	$password = $_POST["password"];

	$datauser = ["$username","$password"];

	$result1 = mysqli_query($db, "SELECT * FROM kasir WHERE username = '$username'");
	$result2 = mysqli_query($db, "SELECT * FROM pemilik WHERE username = '$username'");

	if(mysqli_num_rows($result1)===1)
	{
		$pass=mysqli_fetch_assoc($result1);
		if($password === $pass["password"])
		{
			$_SESSION["pengguna"] = $datauser;
			header("location:kend.php");
			exit;
		}

	}
	if(mysqli_num_rows($result2)===1)
	{
		$pass=mysqli_fetch_assoc($result2);
		if($password === $pass["password"])
		{
			$_SESSION["pengguna"] = $datauser;
			header("location:kend.php");
			exit;
		}
	}
	else
	{
		$error=true;
	}

}

 ?>






<!DOCTYPE html>
<html>
<head>

	<meta name="viewport" content="width=device-width, intial-scale=1">
	<title>Login</title>
		<style type="text/css">
		

  body{
background: url('log.png') no-repeat scroll;
background-size: 100% 100%;
min-height: 700px;

}

.form{
 background:rgba(0, 0, 0, 0.39);
 box-shadow: 0px 0px 20px 6px;
 border-radius:5px;
 width:300px;
 margin:15px auto;
 padding:20px;

}

.form h1{
 color:#eee;
 text-align:center;
}

.form img{
 width:200px;
}

#input{
 background: rgba(23, 20, 20, 0.52);
 font-size:12pt;
 font-family:arial;
 color:#eee;
 width:100%;
 height:40px;
 padding:5px 5px 5px 10px;
 margin:3px;
 border-radius:3px;
 border:none;
}
#input[type="submit"]{
 background:rgba(31, 15, 2, 0.78);
 color:#fff;
 cursor:pointer;
 
}
#input:hover, #input:focus{
 background:rgba(97, 52, 13, 0.55);
 outline-style:none;
}
#input[type="submit"]:hover, #input[type="submit"]:focus{
 background:rgba(31, 15, 2, 0.78);
}


	</style>

<body>
</head>
<body>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
 <div class="form">
  <h1>Login</h1>
 
  <form method="POST" action="#">
   <input id="input" type="text" name="username" placeholder="Username" >
   <input id="input" type="password" name="password" placeholder="Password">
   <input name="login" id="input"  type="submit" value="Login">
  </form>
 </div>

</body>
</html>