<?php 

session_start();

if(!isset($_SESSION["login"])) 
{
	header("location:index.php");
	exit;
 	  
 }

require 'function.php';

$id_jenis = $_GET["kode"];

	if(delete2($id_jenis) > 0)
	{
		echo 
		"
			<script> alert ('Data Berhasil Dihapus');
			document.location.href = 'kend.php'
			</script>
		";
	}
	else
	{
		echo 
		"
			<script> alert ('Data Tidak Berhasil Dihapus');
			document.location.href = 'kend.php'
			</script>
		";
	}


 ?>